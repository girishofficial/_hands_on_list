#/*
#============================================================================
#Name : 7.sh
#Author : Girish Kumar Sahu
#Description : Write a program to copy file1 into file2 ($cp file1 file2).
#Date: 17th Aug, 2024.
#============================================================================
#*/


#!bin/bash


cp "/file1.txt","/file2.txt";
