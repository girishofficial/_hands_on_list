#include <stdio.h>
#include <stdlib.h>

int main(){
	printf("Hello From 26a program\n");
	return 0;
}
